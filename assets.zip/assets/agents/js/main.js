(function ($) {
    "use strict";

    $(".bar").click(function(){
        $(".sidebar-menu, .bar").toggleClass("active");
    });




    
})(jQuery);